package desafio_3;

import desafio_3.tda.*;
import desafio_3.impl.*;
import desafio_3.utils.*;

public class Main {
    public static void main(String[] args)  {
        boolean esUnico;

        System.out.println("---- Desafio 3: Pila que no miente ----");
        System.out.println("Pila Con valores Unicos : Base -> 1 -> 2 -> 3 -> 4 -> 5 -> Tope ");
        System.out.println("Pila Con valores Unicos : Base -> 6 -> 6 -> 7 -> 8 -> 9 -> Tope ");


        PilaTDA pilaUnica = new PilaDinamica();
        PilaTDA pilaRepetida = new PilaDinamica();

        
        for (int i = 1; i < 6; i++) {
            pilaUnica.Apilar(i);
        }

        pilaRepetida.Apilar(6);
        for (int i = 6; i < 10; i++) {
            pilaRepetida.Apilar(i);
        }
        
        System.out.println("-- Resultados de unicidad --");
        esUnico = Util.verificarUnicidad(pilaUnica);
        System.out.println("PilaUnica => " + esUnico);

        esUnico = Util.verificarUnicidad(pilaRepetida);
        System.out.println("PilaRepetida => " + esUnico);

        System.out.println("----------------");
    }

}