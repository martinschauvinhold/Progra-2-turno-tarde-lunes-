package desafio_3.impl;

import desafio_3.tda.PilaTDA;

public class PilaDinamica implements PilaTDA {

    private Node tope; // puntero a nodo tope

    @Override
    public void InicializarPila() {
        tope = null;
    }

    @Override
    public void Apilar(int x) {
        Node node = new Node(x, tope);
        tope = node;
    }

    @Override
    public void Desapilar() {
        if (!PilaVacia()) {
            tope = tope.getNext(); // descartar el previo tope
        }
    }

    @Override
    public int Tope() {
        return tope.getData();
    }

    @Override
    public boolean PilaVacia() {
        return tope == null;
    }
}