package desafio_3.utils;

import desafio_3.impl.ConjuntoDinamico;
import desafio_3.impl.PilaDinamica;
import desafio_3.tda.ConjuntoTDA;
import desafio_3.tda.PilaTDA;

public class Util {
    public static boolean verificarUnicidad(PilaTDA pila) {
        boolean esUnico = true;
        ConjuntoTDA conjuntoAux = new ConjuntoDinamico();
        PilaTDA pilaAux = new PilaDinamica();

        while (!pila.PilaVacia()) {
            int valor = pila.Tope();
            if (conjuntoAux.Pertenece(valor)) {
                esUnico = false;
            }
            else {
                conjuntoAux.Agregar(valor);
            }
            pilaAux.Apilar(valor);
            pila.Desapilar();
        }

        while (!pilaAux.PilaVacia()) {
            pila.Apilar(pilaAux.Tope());
            pilaAux.Desapilar();
        }
        
        return esUnico;

    }
}
