package desafio5;

import desafio_5.impl.ColaPrioridadDinamica;
import desafio_5.tda.ColaTDA;

public class Main {
    public static void main(String[] args) {

        ColaTDA colaSimple = new ColaDinamica();
        ColaTDA aux = new ColaDinamica();
        ColaTDA colaPrio = new ColaPrioridadDinamica();
        int[7] valores = [-3, 5, 0, -1, 7, 2, -4];
        
        while (!colaSimple.ColaVacia()) {
            int valor = colaSimple.Primero();
            if (valor > 0) {
                colaPrio.AcolarPrioridad(valor, 2);
            }
            elif (valor < 0) {
                colaPrio.AcolarPrioridad(valor, 0);
            }
            else {
                colaPrio.AcolarPrioridad(valor, 1);
            }
            aux.Acolar(valor);
            colaSimple.Desacolar();
        }

        while (!aux.ColaVacia()) {
            colaSimple.Acolar(aux.Primero());
            aux.Desacolar();
        }
        
    }
    
}
