package Implementacion;
public class Resolucion {

    public static boolean esPalindromo(ColaDinamica C) {
        PilaDinamica P = new PilaDinamica();
        ColaDinamica CA = new ColaDinamica();

        P.InicializarPila();
        CA.InicializarCola();

        boolean es = true;

        while (!C.ColaVacia()) {
            int x = C.Primero();
            C.Desacolar();

            P.Apilar(x);
            CA.Acolar(x);
        }

        while (!CA.ColaVacia()) {
            int original = CA.Primero();
            CA.Desacolar();

            int invertido = P.Tope();
            P.Desapilar();

            if (original != invertido) {
                es = false;
            }

            C.Acolar(original);
        }

        return es;
    }
}