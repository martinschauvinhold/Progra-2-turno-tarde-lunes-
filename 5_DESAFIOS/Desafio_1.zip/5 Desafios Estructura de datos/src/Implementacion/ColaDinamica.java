package Implementacion;
import Interfaces.ColaTDA;

public class ColaDinamica implements ColaTDA {
    private Node frente;
    private Node fondo;

    public void InicializarCola() {
        this.frente = null;
        this.fondo = null;
    }

    public void Acolar(int x) {
        Node node = new Node(x, (Node)null);
        if (this.ColaVacia()) {
            this.frente = node;
        } else {
            this.fondo.setNext(node);
        }

        this.fondo = node;
    }

    public void Desacolar() {
        if (!this.ColaVacia()) {
            this.frente = this.frente.getNext();
            if (this.frente == null) {
                this.fondo = null;
            }
        }

    }

    public int Primero() {
        return this.frente.getData();
    }

    public boolean ColaVacia() {
        return this.frente == null;
    }
}
