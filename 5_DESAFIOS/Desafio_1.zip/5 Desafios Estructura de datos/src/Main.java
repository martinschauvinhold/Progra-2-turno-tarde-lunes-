import Implementacion.ColaDinamica;
import Implementacion.Resolucion;


public class Main {
            public static void main(String[] args) {
                ColaDinamica C = new ColaDinamica();
                C.InicializarCola();

                C.Acolar(1);
                C.Acolar(2);
                C.Acolar(3);
                C.Acolar(2);
                C.Acolar(1);

                boolean resultado = Resolucion.esPalindromo(C);

                System.out.println(resultado); // true
            }
        }
