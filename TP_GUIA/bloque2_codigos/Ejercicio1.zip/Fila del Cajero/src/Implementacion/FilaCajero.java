package Implementacion;

import Interfaces.Cola;
import Modelo.Cliente;

public class FilaCajero implements Cola<Cliente> {

    private Cliente[] arr;
    private int inx;

    public FilaCajero() {
        arr = new Cliente[100];
        inx = 0;
    }

    @Override
    public void encolar(Cliente cliente) {
        for (int i = inx - 1; i >= 0; i--) {
            arr[i + 1] = arr[i];
        }
        arr[0] = cliente;
        inx++;
    }

    @Override
    public Cliente desencolar() {
        if (estaVacia()) {
            System.out.println("La cola está vacía");
            return null;
        }
        inx--;
        return arr[inx];
    }

    @Override
    public Cliente verPrimero() {
        if (estaVacia()) {
            return null;
        }
        return arr[inx - 1];
    }

    @Override
    public boolean estaVacia() {
        return inx == 0;
    }

    @Override
    public int tamaño() {
        return inx;
    }
}