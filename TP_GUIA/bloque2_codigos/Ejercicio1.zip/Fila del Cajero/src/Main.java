
import Implementacion.FilaCajero;
import Modelo.Cliente;

public class Main {
    public static void main(String[] args) {

        FilaCajero fila = new FilaCajero();

        Cliente c1 = new Cliente("Juan", 1);
        Cliente c2 = new Cliente("Maria", 2);
        Cliente c3 = new Cliente("Pedro", 3);
        Cliente c4 = new Cliente("Samuel", 4 );

        fila.encolar(c1);
        fila.encolar(c2);
        fila.encolar(c3);
        fila.encolar(c4);

        System.out.println("Siguiente cliente: " + fila.verPrimero());

        System.out.println("Atendiendo: " + fila.desencolar());
        System.out.println("Atendiendo: " + fila.desencolar());

        System.out.println("¿Fila vacía? " + fila.estaVacia());
    }
}