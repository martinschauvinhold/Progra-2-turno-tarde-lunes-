package Modelo;

public class Cliente {
    private String nombre;
    private int numeroFila;

    public Cliente(String nombre, int numeroFila) {
        this.nombre = nombre;
        this.numeroFila = numeroFila;
    }
    public String getNombre() {
        return nombre;
    }
    public int getNumeroFila() {
        return numeroFila;
    }
    @Override
    public String toString() {
        return "Cliente: " + nombre + " | Número en fila: " + numeroFila;
    }
}