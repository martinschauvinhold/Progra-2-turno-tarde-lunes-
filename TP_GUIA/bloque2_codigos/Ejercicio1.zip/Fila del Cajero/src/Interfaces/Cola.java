package Interfaces;

public interface Cola<T> {
    void encolar(T elemento);
    T desencolar();
    T verPrimero();
    boolean estaVacia();
    int tamaño();
}