package main;

import tda.ColaTDA;
import impl.ColaCircular;
import model.Cliente;

public class MainBuffet {
    public static void main(String[] args) {

        ColaTDA<Cliente> fila = new ColaCircular<>();
        fila.inicializarCola();

        fila.acolar(new Cliente("Martín"));
        fila.acolar(new Cliente("Sofía"));
        fila.acolar(new Cliente("Facundo"));
        fila.acolar(new Cliente("Maribel"));
        fila.acolar(new Cliente("Samuel"));
        fila.acolar(new Cliente("Agustín")); // vibe coder crónico

        System.out.println("= Buffet de la Facultad : Sandwitch de Milanga =");
        System.out.println("Operación ENCOLAR evita colados (agrega al final)");
        System.out.println("Operación DESACOLAR despacha al primero siempre");
        System.out.println();
        System.out.println("Orden de atención:");
        int ticketId = 1;
        while (!fila.colaVacia()) {
            System.out.println("#" + ticketId++ + ": " + fila.primero());
            fila.desacolar();
        }
        System.out.println("\nNadie se coló");
    }
}