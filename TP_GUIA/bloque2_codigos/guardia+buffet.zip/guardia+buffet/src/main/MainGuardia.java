package main;

import tda.ColaConPrioridadTDA;
import impl.ColaConPrioridad;
import model.Paciente;

public class MainGuardia {
    public static void main(String[] args) {

        System.out.println("= Situación dada =");
        ColaConPrioridadTDA<Paciente> guardia = new ColaConPrioridad<>();
        guardia.inicializarCola();

        guardia.acolarPrioridad(new Paciente("Enrique",       "Raspón en la rodilla"), 1);
        guardia.acolarPrioridad(new Paciente("Alberto", "bobazo en la cabeza"),    100);

        int turnoId = 1;
        while (!guardia.colaVacia()) {
            System.out.println("  Turno " + turnoId++ + ": " + guardia.primero());
            guardia.desacolar();
        }

        // Consigna de 3 casos

        System.out.println("\n= casos adicionales =\n");
        ColaConPrioridadTDA<Paciente> triage = new ColaConPrioridad<>();
        triage.inicializarCola();

        // caso 1 llegan desordenados se atienden por urgencia

        System.out.println("Caso 1 urgencias mezcladas:");
        triage.acolarPrioridad(new Paciente("Lucas",   "Fiebre leve"),       5);
        triage.acolarPrioridad(new Paciente("Martina", "Fractura de fémur"),  75);
        triage.acolarPrioridad(new Paciente("Roberto", "Paro cardíaco"),      100);

        turnoId = 1;
        while (!triage.colaVacia()) {
            System.out.println("  Turno " + turnoId++ + ": " + triage.primero());
            triage.desacolar();
        }

        // caso 2 todos misma priorida se sigue por orden llegada

        System.out.println("\nCaso 2  misma prioridad:");
        triage.inicializarCola();
        triage.acolarPrioridad(new Paciente("Ana",   "Dolor de cabeza"), 15);
        triage.acolarPrioridad(new Paciente("Bruno", "Dolor de espalda"), 15);
        triage.acolarPrioridad(new Paciente("Clara", "Mareos"),           15);

        turnoId = 1;
        while (!triage.colaVacia()) {
            System.out.println("  Turno " + turnoId++ + ": " + triage.primero());
            triage.desacolar();
        }

        // caso 3 llegan en orden inverso al de urgencia

        System.out.println("\nCaso 3 llegan de menor a mayor urgencia:");
        triage.inicializarCola();
        triage.acolarPrioridad(new Paciente("Sofía",  "Uña encarnada"),      10);
        triage.acolarPrioridad(new Paciente("Javier", "Hemorragia interna"),  95);
        triage.acolarPrioridad(new Paciente("Elena",  "Paro respiratorio"),   100);

        turnoId = 1;
        while (!triage.colaVacia()) {
            System.out.println("  Turno " + turnoId++ + ": " + triage.primero());
            triage.desacolar();
        }
    }
}