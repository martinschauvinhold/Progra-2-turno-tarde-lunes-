package tda;

public interface ColaConPrioridadTDA<T> { //TDA generico para colas FIFO con prioridad
    void inicializarCola();
    void acolarPrioridad(T elemento, int prioridad);
    void desacolar();

    T primero();
    boolean colaVacia();
    
}
