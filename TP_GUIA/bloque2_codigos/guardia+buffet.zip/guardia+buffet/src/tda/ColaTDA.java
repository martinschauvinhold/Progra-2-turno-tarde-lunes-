package tda;

public interface ColaTDA<T> { // TDA generico para colas FIFO sin prioridad
    void inicializarCola();
    void acolar(T elemento);
    void desacolar();

    T primero();
    boolean colaVacia();
    
}