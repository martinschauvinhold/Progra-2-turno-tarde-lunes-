package impl;

import tda.ColaConPrioridadTDA;

public class ColaConPrioridad<T> implements ColaConPrioridadTDA<T> {
    private static final int CAPACIDAD = 100;

    private T[]   elementos;
    private int[] prioridades; // se podría optimizar
    private int   tamanio;


    @Override
    @SuppressWarnings("unchecked") // para silenciar la advertencia por el casteo a T
    public void inicializarCola() {
        elementos   = (T[]) new Object[CAPACIDAD];
        prioridades = new int[CAPACIDAD];
        tamanio     = 0;
    }

    @Override
    public void acolarPrioridad(T elemento, int prioridad) {
        if (tamanio == CAPACIDAD) throw new RuntimeException("Cola llena");
        int i = tamanio - 1;
        while (i >= 0 && prioridades[i] < prioridad) {
            elementos[i + 1]   = elementos[i];
            prioridades[i + 1] = prioridades[i];
            i--;
        }
        elementos[i + 1]   = elemento;
        prioridades[i + 1] = prioridad;
        tamanio++;
    }

    @Override
    public void desacolar() {
        if (colaVacia()) throw new RuntimeException("Cola vacía");
        for (int i = 0; i < tamanio - 1; i++) {
            elementos[i]   = elementos[i + 1];
            prioridades[i] = prioridades[i + 1];
        }
        elementos[tamanio - 1]   = null; // eliminar referencia 
        tamanio--;
    }

    @Override
    public T primero() {
        if (colaVacia()) throw new RuntimeException("Cola vacía");
        return elementos[0];
    }

    @Override
    public boolean colaVacia() {
        return tamanio == 0;
    }
}
