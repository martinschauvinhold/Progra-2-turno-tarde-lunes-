package impl;

import tda.ColaTDA;

public class ColaCircular<T> implements ColaTDA<T> {
    private static final int CAPACIDAD = 100;

    private T[]  elementos;
    private int  frente;
    private int  fin;
    private int  tamanio;

    @Override
    @SuppressWarnings("unchecked") // para silenciar la advertencia por el casteo a T
    public void inicializarCola() {
        elementos = (T[]) new Object[CAPACIDAD];
        frente    = 0;
        fin       = 0;
        tamanio   = 0;
    }


    @Override
    public void acolar(T elemento) {
        if (tamanio == CAPACIDAD) throw new RuntimeException("Cola llena");
        elementos[fin] = elemento;
        fin = (fin + 1) % CAPACIDAD;    // posicion de avance circular con módulo
        tamanio++;
    }

    @Override
    public void desacolar() {
        if (colaVacia()) throw new RuntimeException("Cola vacía");
        elementos[frente] = null;             // eliminar referencia
        frente = (frente + 1) % CAPACIDAD;   // posicion de avance circular con módulo
        tamanio--;
    }

    @Override
    public T primero() {
        if (colaVacia()) throw new RuntimeException("Cola vacía");
        return elementos[frente];
    }

    @Override
    public boolean colaVacia() {
        return tamanio == 0;
    }

    public int tamanio() { return tamanio; } // original de la implementacion
}