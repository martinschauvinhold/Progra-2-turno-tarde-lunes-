package model;

// clase simple para representar a los pacientes de la guardia

public class Paciente {
    private String nombre;
    private String diagnostico;

    public Paciente(String nombre, String diagnostico) {
        this.nombre = nombre;
        this.diagnostico = diagnostico;
    }

    public String getNombre() { return nombre; }
    public String getDiagnostico() { return diagnostico; }

    @Override
    public String toString() {
        return nombre + " (" + diagnostico + ")";
    }
}
