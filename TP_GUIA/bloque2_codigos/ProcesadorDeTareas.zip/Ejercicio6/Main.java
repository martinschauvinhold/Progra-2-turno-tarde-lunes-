package chiteado.colasPrioridad;

public class Main {

	public static void main(String[] args) {
		ColaPrioridadTDA c = new ColaPrioridadDA();
		c.InicializarCola();
		
		c.AcolarPrioridad(1, 5);
		c.AcolarPrioridad(7, 2);
		c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);
        c.AcolarPrioridad(2, 8);








		c.MostrarCola();
		//c.MostrarCola();
		//c.MostrarCola();

	}

}
