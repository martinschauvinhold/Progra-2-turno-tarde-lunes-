package Implementacion;

import Interfaces.ColaTDA;

public class ColaSimple implements ColaTDA {
	private int[] arr;
	private int indice;

	@Override
	public void InicializarCola() {
		arr = new int[100];
		indice = 0;
	}

	@Override
	public void Acolar(int x) {
		// El nuevo archivo entra al final de la fila
		arr[indice] = x;
		indice++;
	}

	@Override
	public void Desacolar() {
		// El archivo en arr[0] ya se imprimió.
		// Movemos todos un pasito hacia adelante para cubrir el hueco.
		for (int i = 0; i < indice - 1; i++) {
			arr[i] = arr[i + 1];
		}
		indice--;
	}

	@Override
	public boolean ColaVacia() {
		return indice == 0;
	}

	@Override
	public int Primero() {
		// El primero siempre es el que está en la posición 0
		return arr[0];
	}
}