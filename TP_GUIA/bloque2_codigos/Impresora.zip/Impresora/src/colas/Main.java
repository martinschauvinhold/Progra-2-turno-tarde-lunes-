package colas;

import Implementacion.ColaSimple;
import Interfaces.ColaTDA;

public class Main {
    public static void main(String[] args) {
        // 1. Inicializamos la impresora
        ColaTDA impresoraLab = new ColaSimple();
        impresoraLab.InicializarCola();

        System.out.println("--- Recepción de TPs en la Impresora ---");

        // 2. Mandan los TPs. Usamos el legajo/ID como número.
        impresoraLab.Acolar(101); System.out.println("Llegó el TP 101");
        impresoraLab.Acolar(102); System.out.println("Llegó el TP 102");
        impresoraLab.Acolar(103); System.out.println("Llegó el TP 103");
        impresoraLab.Acolar(104); System.out.println("Llegó el TP 104");
        impresoraLab.Acolar(105); System.out.println("Llegó el TP 105");
        impresoraLab.Desacolar();
        impresoraLab.Desacolar();



        System.out.println("\n--- Orden de Salida (Impresión) ---");

        System.out.print("Orden de salida: ");
        while (!impresoraLab.ColaVacia()) {
            System.out.print(impresoraLab.Primero() + " "); // Imprime con un espacio
            impresoraLab.Desacolar(); // Lo saca para poder leer el siguiente
        }
    }
}