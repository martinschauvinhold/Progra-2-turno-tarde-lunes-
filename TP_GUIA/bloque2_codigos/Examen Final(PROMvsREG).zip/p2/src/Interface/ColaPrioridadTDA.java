package Interface;

public interface ColaPrioridadTDA {
    void InicializarCola();
    void AcolarPrioridad(int x, int prioridad);
    int Desacolar();
    int Primero();
    boolean ColaVacia();
    int Prioridad();
}
