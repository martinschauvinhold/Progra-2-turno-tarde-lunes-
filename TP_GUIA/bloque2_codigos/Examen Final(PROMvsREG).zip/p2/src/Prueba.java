import Implementacion.Alumno;
import Implementacion.ColaPrioridad;

public class Prueba {
    public static void main(String[] args) {
        ColaPrioridad filaExamen = new ColaPrioridad();

        filaExamen.InicializarCola();

        filaExamen.AcolarPrioridad(new Alumno("Juan (Regular)", 5, 830));
        filaExamen.AcolarPrioridad(new Alumno("Lisa (Regular)", 5, 800));
        filaExamen.AcolarPrioridad(new Alumno("Maria (Promociona)", 10, 830));
        filaExamen.AcolarPrioridad(new Alumno("Lucas (Promociona)", 10, 800));

        while (!filaExamen.ColaVacia()) {
            Alumno actual = filaExamen.Primero();
            int prioridad = filaExamen.Prioridad();

            System.out.println("Saliendo: " + actual.nombre + " [Prioridad: " + prioridad + "]");

            filaExamen.Desacolar();
        }
    }
}
