package Implementacion;

public class Alumno {
    public String nombre;
    int prioridad;
    int hora;

    public Alumno(String nombre, int prioridad, int hora) {
        this.nombre = nombre;
        this.prioridad = prioridad;
        this.hora = hora;
    }
}
