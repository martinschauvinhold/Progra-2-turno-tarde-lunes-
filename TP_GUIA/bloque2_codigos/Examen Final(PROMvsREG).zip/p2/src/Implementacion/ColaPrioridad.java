package Implementacion;

public class ColaPrioridad {
    private class Nodo {
        Alumno alumno;
        Nodo siguiente;
    }

    private Nodo mayor;

    public void InicializarCola() {
        mayor = null;
    }

    public void AcolarPrioridad(Alumno nuevoAlumno) {
        Nodo nuevoNodo = new Nodo();
        nuevoNodo.alumno = nuevoAlumno;


        if (mayor == null || comparar(nuevoAlumno, mayor.alumno) < 0) {
            nuevoNodo.siguiente = mayor;
            mayor = nuevoNodo;
        } else {

            Nodo aux = mayor;
            while (aux.siguiente != null && comparar(nuevoAlumno, aux.siguiente.alumno) >= 0) {
                aux = aux.siguiente;
            }
            nuevoNodo.siguiente = aux.siguiente;
            aux.siguiente = nuevoNodo;
        }
    }

    private int comparar(Alumno a, Alumno b) {
        if (a.prioridad != b.prioridad) {
            return b.prioridad - a.prioridad;
        }
        return a.hora - b.hora;
    }

    public void Desacolar() {
        if (!ColaVacia()) {
            mayor = mayor.siguiente;
        }
    }

    public Alumno Primero() {
        return mayor.alumno;
    }

    public int Prioridad() {
        return mayor.alumno.prioridad;
    }

    public boolean ColaVacia() {
        return (mayor == null);
    }

}
