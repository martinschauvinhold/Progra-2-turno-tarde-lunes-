package desafio_final;

import desafio_final.impl.ConjuntoImpl;
import desafio_final.modelo.SistemaInscripciones;
import desafio_final.tda.ConjuntoTDA;

public class Main {

    public static void main(String[] args) {

        SistemaInscripciones sistema = new SistemaInscripciones();

        sistema.agregarMateria("ALG1", "Álgebra 1",        30);
        sistema.agregarMateria("MAT1", "Matemática Discreta", 30);
        sistema.agregarMateria("ALG2", "Álgebra 2",         3);

        sistema.agregarCorrelativa("ALG2", "ALG1");
        sistema.agregarCorrelativa("ALG2", "MAT1");

        ConjuntoTDA aprobL1001 = armarAprobadas("ALG1", "MAT1");
        ConjuntoTDA aprobL1002 = armarAprobadas("ALG1", "MAT1");
        ConjuntoTDA aprobL1003 = armarAprobadas("ALG1", "MAT1");
        ConjuntoTDA aprobL1004 = armarAprobadas("ALG1");
        ConjuntoTDA aprobL1005 = armarAprobadas("ALG1", "MAT1");
        ConjuntoTDA aprobL1006 = armarAprobadas("ALG1", "MAT1");

        System.out.println("========================================");
        System.out.println("  Sistema Inscripciones ");
        System.out.println("========================================\n");

        System.out.println("> Inscribiendo alumnos en ALG2 (cupo 3):\n");

        sistema.inscribirAlumno(1001, "ALG2", false, aprobL1001);
        sistema.inscribirAlumno(1002, "ALG2", false, aprobL1002);
        sistema.inscribirAlumno(1003, "ALG2", false, aprobL1003);
        sistema.inscribirAlumno(1004, "ALG2", false, aprobL1004);
        sistema.inscribirAlumno(1005, "ALG2", false, aprobL1005);
        sistema.inscribirAlumno(1006, "ALG2", true,  aprobL1006);

        System.out.println("\n> Intento duplicado:");
        sistema.inscribirAlumno(1001, "ALG2", false, aprobL1001);

        sistema.mostrarInscriptos("ALG2");
        sistema.mostrarListaEspera("ALG2");

        System.out.println("\n > Baja de L1002:");
        sistema.darDeBaja(1002, "ALG2");

        sistema.mostrarInscriptos("ALG2");
        sistema.mostrarListaEspera("ALG2");

        System.out.println("\n========================================\n");
    }

    private static ConjuntoTDA armarAprobadas(String... codigos) {
        ConjuntoTDA c = new ConjuntoImpl();
        c.InicializarConjunto();
        for (String cod : codigos) c.Agregar(cod.hashCode());
        return c;
    }
}