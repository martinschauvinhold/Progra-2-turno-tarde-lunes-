package desafio_final.tda;

public interface DiccionarioMultipleTDA {
    void InicializarDiccionario();
    void Agregar(String clave, int valor);
    void EliminarValor(String clave, int valor);
    void Eliminar(String clave);
    ConjuntoTDA Recuperar(String clave);
    ConjuntoTDA Claves();
}