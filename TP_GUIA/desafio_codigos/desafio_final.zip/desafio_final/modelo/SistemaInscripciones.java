package desafio_final.modelo;

import desafio_final.impl.ConjuntoImpl;
import desafio_final.impl.ColaConPrioridadImpl;
import desafio_final.impl.DiccionarioMultipleImpl;
import desafio_final.tda.ConjuntoTDA;
import desafio_final.tda.ColaConPrioridadTDA;
import desafio_final.tda.DiccionarioMultipleTDA;

import java.util.HashMap;
import java.util.Map;

public class SistemaInscripciones { 

    private final Map<String, Materia> materias = new HashMap<>();
    private DiccionarioMultipleTDA correlatividades;

    public SistemaInscripciones() {
        correlatividades = new DiccionarioMultipleImpl();
        correlatividades.InicializarDiccionario();
    }

    public void agregarMateria(String codigo, String nombre, int cupo) {
        materias.put(codigo, new Materia(codigo, nombre, cupo));
    }

    public void agregarCorrelativa(String materia, String previa) {
        correlatividades.Agregar(materia, previa.hashCode());
    }

    public boolean cumpleCorrelativas(String materia, ConjuntoTDA aprobadas) {
        ConjuntoTDA previas = correlatividades.Recuperar(materia);
        if (previas == null) return true;

        ConjuntoTDA aux = new ConjuntoImpl();
        aux.InicializarConjunto();
        boolean cumple = true;

        while (!previas.ConjuntoVacio()) {
            int codPrevia = previas.Elegir();
            previas.Sacar(codPrevia);
            aux.Agregar(codPrevia);
            if (!aprobadas.Pertenece(codPrevia)) cumple = false;
        }

        while (!aux.ConjuntoVacio()) {
            int cod = aux.Elegir();
            aux.Sacar(cod);
            previas.Agregar(cod);
        }

        return cumple;
    }


    public void inscribirAlumno(int legajo, String codigoMateria, boolean esEmpleadoDepto, ConjuntoTDA aprobadas) {

        Materia materia = materias.get(codigoMateria);

        if (materia == null) {
            System.out.println("ERROR: Materia " + codigoMateria + " no existe.");
            return;
        }

        if (materia.estaInscripto(legajo)) {
            System.out.println("Legajo " + legajo + " ya está inscripto en " + materia.getNombre() + ".");
            return;
        }

        if (!cumpleCorrelativas(codigoMateria, aprobadas)) {
            System.out.println("Legajo " + legajo + " NO cumple correlativas para " + materia.getNombre() + ". Inscripción rechazada.");
            return;
        }

        if (materia.tieneLugar()) {
            materia.inscribirDirecto(legajo);
            System.out.println("Legajo " + legajo + " inscripto en " + materia.getNombre() + ".");

        } else {
            int prioridad = esEmpleadoDepto
                ? Materia.PRIORIDAD_EMPLEADO_DEPTO
                : Materia.PRIORIDAD_ALUMNO_COMUN;
            materia.encolarEspera(legajo, prioridad);
            System.out.println("EN ESPERA  Legajo " + legajo + (esEmpleadoDepto ? " [Empleado Depto]" : " [Alumno común]") +
                               " en lista de espera pra " + materia.getNombre() + " (prioridad " + prioridad + ").");
        }
    }


    public void darDeBaja(int legajo, String codigoMateria) {
        Materia materia = materias.get(codigoMateria);
        if (materia == null) return;
        if (!materia.estaInscripto(legajo)) {
            System.out.println("Legajo " + legajo + " no estaba inscripto en "
                + materia.getNombre() + ".");
            return;
        }
        materia.darDeBaja(legajo);
        System.out.println("BAJA  Legajo " + legajo + " dado de baja en "
            + materia.getNombre() + ".");
    }


    public void mostrarInscriptos(String codigoMateria) {
        Materia materia = materias.get(codigoMateria);
        if (materia == null) return;

        System.out.println("\n= Inscriptos en " + materia.getNombre() + " (" + materia.cantidadInscriptos() + "/" + materia.getCupoMaximo() + ") =");

        ConjuntoTDA aux = new ConjuntoImpl();
        aux.InicializarConjunto();
        ConjuntoTDA inscriptos = materia.getInscriptos();

        while (!inscriptos.ConjuntoVacio()) {
            int leg = inscriptos.Elegir();
            inscriptos.Sacar(leg);
            aux.Agregar(leg);
            System.out.println("  Legajo: " + leg);
        }

        while (!aux.ConjuntoVacio()) {
            int leg = aux.Elegir();
            aux.Sacar(leg);
            inscriptos.Agregar(leg);
        }
    }

    public void mostrarListaEspera(String codigoMateria) {
        Materia materia = materias.get(codigoMateria);
        if (materia == null) return;

        System.out.println("\n= Lista de espera: " + materia.getNombre() + " =");

        if (materia.getListaEspera().ColaVacia()) {
            System.out.println("  (vacía)");
            return;
        }

        int pos = 1;

        ColaConPrioridadTDA aux = new ColaConPrioridadImpl();
        aux.InicializarCola();
        ColaConPrioridadTDA cola = materia.getListaEspera();

        while (!cola.ColaVacia()) {
            int leg  = cola.Primero();
            int prio = cola.Prioridad();
            cola.Desacolar();
            aux.AcolarPrioridad(leg, prio);
            System.out.println("  " + pos++ + ". Legajo " + leg + " | prioridad " + prio
                               + (prio == Materia.PRIORIDAD_EMPLEADO_DEPTO ? " [Empleado Depto]" : " [Alumno común]"));
        }

        while (!aux.ColaVacia()) {
            materia.getListaEspera().AcolarPrioridad(aux.Primero(), aux.Prioridad());
            aux.Desacolar();
        }
    }
}