package desafio_final.modelo;

import desafio_final.impl.ConjuntoImpl;
import desafio_final.impl.ColaConPrioridadImpl;
import desafio_final.tda.ConjuntoTDA;
import desafio_final.tda.ColaConPrioridadTDA;

public class Materia {

    public static final int PRIORIDAD_EMPLEADO_DEPTO = 2;
    public static final int PRIORIDAD_ALUMNO_COMUN   = 1;

    private final String codigo;
    private final String nombre;
    private final int cupoMaximo;

    private ConjuntoTDA      inscriptos;
    private ColaConPrioridadTDA listaEspera;

    public Materia(String codigo, String nombre, int cupoMaximo) {
        this.codigo     = codigo;
        this.nombre     = nombre;
        this.cupoMaximo = cupoMaximo;

        this.inscriptos = new ConjuntoImpl();
        this.inscriptos.InicializarConjunto();

        this.listaEspera = new ColaConPrioridadImpl();
        this.listaEspera.InicializarCola();
    }

    public String getCodigo()  { return codigo; }
    public String getNombre()  { return nombre; }
    public int getCupoMaximo() { return cupoMaximo; }

    public boolean estaInscripto(int legajo) {
        return inscriptos.Pertenece(legajo);
    }

    public boolean tieneLugar() {
        return cantidadInscriptos() < cupoMaximo;
    }

    public int cantidadInscriptos() {
        int count = 0;
        ConjuntoTDA aux = new ConjuntoImpl();
        aux.InicializarConjunto();
        while (!inscriptos.ConjuntoVacio()) {
            int leg = inscriptos.Elegir();
            inscriptos.Sacar(leg);
            aux.Agregar(leg);
            count++;
        }

        while (!aux.ConjuntoVacio()) { // reinsercion
            int leg = aux.Elegir();
            aux.Sacar(leg);
            inscriptos.Agregar(leg);
        }
        return count;
    }

    public boolean inscribirDirecto(int legajo) {
        if (inscriptos.Pertenece(legajo)) return false;
        if (!tieneLugar())                return false;
        inscriptos.Agregar(legajo);
        return true;
    }

    public void encolarEspera(int legajo, int prioridad) {
        listaEspera.AcolarPrioridad(legajo, prioridad);
    }

    public void darDeBaja(int legajo) {
        if (!inscriptos.Pertenece(legajo)) return;

        inscriptos.Sacar(legajo);

        if (tieneLugar() && !listaEspera.ColaVacia()) {
            int siguiente = listaEspera.Primero();
            listaEspera.Desacolar();
            inscriptos.Agregar(siguiente);
        }
    }

    public ConjuntoTDA      getInscriptos()  { return inscriptos;  }
    public ColaConPrioridadTDA getListaEspera() { return listaEspera; }
}