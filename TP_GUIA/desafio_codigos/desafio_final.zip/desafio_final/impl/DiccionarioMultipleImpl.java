package desafio_final.impl;

import desafio_final.tda.ConjuntoTDA;
import desafio_final.tda.DiccionarioMultipleTDA;

public class DiccionarioMultipleImpl implements DiccionarioMultipleTDA {

    private static final int MAX = 100;
    private String[]     claves;
    private ConjuntoTDA[] valores;  
    private int cantidad;

    @Override
    public void InicializarDiccionario() {
        claves   = new String[MAX];
        valores  = new ConjuntoTDA[MAX];
        cantidad = 0;
    }

    private int buscarIndice(String clave) {
        for (int i = 0; i < cantidad; i++) {
            if (claves[i].equals(clave)) return i;
        }
        return -1;
    }

    @Override
    public void Agregar(String clave, int valor) {
        int idc = buscarIndice(clave);

        if (cantidad == MAX && idc == -1) {
            throw new RuntimeException("Diccionario lleno");
        }

        if (idc == -1) {
            claves[cantidad]  = clave;
            valores[cantidad] = new ConjuntoImpl();
            valores[cantidad].InicializarConjunto();
            valores[cantidad].Agregar(valor);
            cantidad++;
        } else {
            valores[idc].Agregar(valor);
        }
    }

    @Override
    public void EliminarValor(String clave, int valor) {
        int idc = buscarIndice(clave);
        if (idc != -1) valores[idc].Sacar(valor);
    }

    @Override
    public void Eliminar(String clave) {
        int idc = buscarIndice(clave);
        if (idc == -1) return;
        claves[idc]  = claves[cantidad - 1];
        valores[idc] = valores[cantidad - 1];
        cantidad--;
    }

    @Override
    public ConjuntoTDA Recuperar(String clave) {
        int idc = buscarIndice(clave);
        return (idc != -1) ? valores[idc] : null;
    }

    @Override
    public ConjuntoTDA Claves() {
        ConjuntoTDA resultado = new ConjuntoImpl();
        resultado.InicializarConjunto();
        for (int i = 0; i < cantidad; i++) {
            resultado.Agregar(claves[i].hashCode()); // .hashCode() dado que la clave es un string pero el conjuntoTDA solo acepta int. Esto para no usar un TDA genérico 
                                                     // Podría ocurrir que 2 strings diferentes den mismo hash.
        }
        return resultado;
    }
}