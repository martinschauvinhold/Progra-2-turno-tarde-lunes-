package desafio_final.impl;

import desafio_final.tda.ColaConPrioridadTDA;

public class ColaConPrioridadImpl implements ColaConPrioridadTDA {

    private static final int MAX = 100;
    private int[] valores;
    private int[] prioridades;
    private int cantidad;

    @Override
    public void InicializarCola() {
        valores     = new int[MAX];
        prioridades = new int[MAX];
        cantidad    = 0;
    }

    @Override
    public void AcolarPrioridad(int x, int prioridad) {
        if (cantidad == MAX) {
            throw new RuntimeException("Cola llena");
        }

        int pos = cantidad;

        for (int i = 0; i < cantidad && pos == cantidad; i++) {
            if (prioridad > prioridades[i]) {
                pos = i;
            }
        }

        // ordernar a la derecha derecha
        for (int i = cantidad; i > pos; i--) {
            valores[i]     = valores[i - 1];
            prioridades[i] = prioridades[i - 1];
        }

        valores[pos]     = x;
        prioridades[pos] = prioridad;

        cantidad++;
    }

    @Override
    public void Desacolar() {
        if (ColaVacia()) {
            throw new RuntimeException("Cola vacía");
        }
        // desacolar y desplazar a izq (indice 0 es el mayor prio + primera llegada)
        for (int i = 0; i < cantidad - 1; i++) {
            valores[i]     = valores[i + 1];
            prioridades[i] = prioridades[i + 1];
        }
        cantidad--;
    }

    @Override
    public int Primero() {
        if (ColaVacia()) {
            throw new RuntimeException("Cola vacía");
        } return valores[0];
    }

    @Override
    public int Prioridad() {
        if (ColaVacia()) {
            throw new RuntimeException("Cola vacía");
        } return prioridades[0];
    }

    @Override
    public boolean ColaVacia() {
        return cantidad == 0;
    }
}