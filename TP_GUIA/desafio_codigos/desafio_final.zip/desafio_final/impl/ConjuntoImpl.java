package desafio_final.impl;

import desafio_final.tda.ConjuntoTDA;

public class ConjuntoImpl implements ConjuntoTDA {

    private static final int MAX = 100;
    private int[] datos;
    private int cantidad;

    @Override
    public void InicializarConjunto() {
        datos = new int[MAX];
        cantidad = 0;
    }

    @Override
    public void Agregar(int x) {
        if (cantidad == MAX) {
            throw new RuntimeException("Conjunto lleno");
        }
        if (!Pertenece(x)) {
            datos[cantidad] = x;
            cantidad++;
        }
    }

    @Override
    public void Sacar(int x) {
        for (int i = 0; i < cantidad; i++) {
            if (datos[i] == x) {
                datos[i] = datos[cantidad - 1]; 
                cantidad--;
                return;
            }
        }
    }

    @Override
    public boolean Pertenece(int x) {
        for (int i = 0; i < cantidad; i++) {
            if (datos[i] == x) return true;
        }
        return false;
    }

    @Override
    public boolean ConjuntoVacio() {
        return cantidad == 0;
    }

    @Override
    public int Elegir() {
        if (ConjuntoVacio()) {
            throw new RuntimeException("Conjunto vacío");
        } return datos[0];
    }
}